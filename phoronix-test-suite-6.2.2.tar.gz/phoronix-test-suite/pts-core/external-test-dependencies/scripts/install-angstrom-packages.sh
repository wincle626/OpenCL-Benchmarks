#!/bin/sh
opkg install $*
