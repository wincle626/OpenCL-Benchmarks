#!/bin/sh
rm -rf bin CMakeFiles Makefile
rm CMakeCache.txt cmake_install.cmake
