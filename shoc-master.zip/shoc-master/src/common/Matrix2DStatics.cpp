#include "Matrix2D.h"

template<> PMSMemMgr<float>* Matrix2D<float>::pmsmm = 0;
template<> PMSMemMgr<double>* Matrix2D<double>::pmsmm = 0;

