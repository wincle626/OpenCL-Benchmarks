SmallPTGPU
===========

SmallptGPU is a small and simple demo written in OpenCL in order to test the
performance of this new standard. It is based on Kevin Beason's Smallpt available
at http://www.kevinbeason.com/smallpt/. The idea to apply scattering to SmallPT
was borrowed from D-Power's SmallVPT available at http://github.com/D-POWER/smallvpt.

This demo works with OpenCL 1.0.


Key bindings
============

Check the on screen help.


History
=======

V1.0 - First release of SmallPTGPU
